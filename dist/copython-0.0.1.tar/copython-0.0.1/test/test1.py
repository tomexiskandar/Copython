import copython
from os import path

# test 
if __name__=="__main__":
    config_path = "E:\Documents\Visual Studio 2017\Projects\copython\test\_test_cf_load_csv_tab_into_mssql.xml"
    copython.copython(config_path)
