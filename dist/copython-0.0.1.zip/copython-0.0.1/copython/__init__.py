from copython.copython import copy_data, drop_table,gen_xml_cf_template
