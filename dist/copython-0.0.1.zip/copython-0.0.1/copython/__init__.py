from copython.copython import copy_data, drop_table
from copython.copython import drop_table
