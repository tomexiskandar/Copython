def progress():
    print('|',end='',flush=True)
