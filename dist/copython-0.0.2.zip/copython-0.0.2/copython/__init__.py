from copython.copython import copy_data, drop_table
